#!/bin/sh

g++ rainbow.cpp grader.cpp -o rainbow -O2 -static -std=c++11
