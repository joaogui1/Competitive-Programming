#include "rainbow.h"

void init(int R, int C, int sr, int sc, int M, char *S) {
}

int colour(int ar, int ac, int br, int bc) {
    return 0;
}

