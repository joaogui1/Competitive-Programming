#ifndef __RAINBOW_H
#define __RAINBOW_H

void init(int R, int C, int sr, int sc, int M, char *S);
int colour(int ar, int ac, int br, int bc);

#endif  // __RAINBOW_H
