#pragma once

long long take_photos(int n, int m, int k, int* r, int* c);

