
/* For the player */
int GetRequest();
void PutBack(int T);
