
/* For the advisor */
void WriteAdvice(unsigned char a);
