
#include "advisor.h"

void ComputeAdvice(int *C, int N, int K, int M) {

  WriteAdvice(0);
  WriteAdvice(1);
  WriteAdvice(2);

}
