#ifndef __ICC_H__
#define __ICC_H__

#ifdef __cplusplus
extern "C" {
#endif

void run(int);

int query(int a, int b, int *A, int *B);
void setRoad(int a, int b);

#ifdef __cplusplus
}
#endif

#endif // __ICC_H__
