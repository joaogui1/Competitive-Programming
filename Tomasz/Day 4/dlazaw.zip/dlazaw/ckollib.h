#ifdef __cplusplus
extern "C" {
#endif

int karta();
void odpowiedz(int wynik);

#ifdef __cplusplus
}
#endif
